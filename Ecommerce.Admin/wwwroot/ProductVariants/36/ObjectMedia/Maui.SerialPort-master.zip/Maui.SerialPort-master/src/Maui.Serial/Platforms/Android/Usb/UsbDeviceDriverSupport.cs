﻿namespace Maui.Serial.Platforms.Android.Usb;

public record UsbDeviceDriverSupport(int VendorId, int[] DeviceIds);
