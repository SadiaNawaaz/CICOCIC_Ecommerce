﻿namespace Maui.Serial;

public enum StopBits
{
    NotSet = -1,
    One = 1,
    OnePointFive = 3,
    Two = 2
}
