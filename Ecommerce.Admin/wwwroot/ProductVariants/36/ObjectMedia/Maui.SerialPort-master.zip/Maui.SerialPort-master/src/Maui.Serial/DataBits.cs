﻿namespace Maui.Serial;

public enum DataBits
{
    Bits5 = 5,
    Bits6 = 6,
    Bits7 = 7,
    Bits8 = 8,
}

