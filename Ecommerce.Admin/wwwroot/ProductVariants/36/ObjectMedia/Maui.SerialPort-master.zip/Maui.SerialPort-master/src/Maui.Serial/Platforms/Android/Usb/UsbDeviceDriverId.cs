﻿namespace Maui.Serial.Platforms.Android.Usb;

public record UsbDeviceDriverId(int VendorId, int DeviceId);

