# Maui.SerialPort

Maui Library for handling serial port in Windows & Android. 

Based on https://github.com/anotherlab/UsbSerialForAndroid
